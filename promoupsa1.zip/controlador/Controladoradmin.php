<?php
header("location: /promoupsa1/vista/mainn2.html");